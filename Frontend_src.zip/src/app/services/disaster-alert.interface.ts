export interface IDisasterAlert {
    type: string;
    details: string;
    location: string;
    createdAt: Date;
  }
  