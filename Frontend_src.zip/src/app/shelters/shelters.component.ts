import { Component, OnInit } from '@angular/core';
import { ShelterService } from '../services/shelter.service';

@Component({
  selector: 'app-shelters',
  templateUrl: './shelters.component.html',
  styleUrls: ['./shelters.component.css'],
})
export class SheltersComponent implements OnInit {
  newShelter = {
    name: '',
    address: '',
    location: '', // City name or coordinates
    capacity: 0,
  };

  shelters: any[] = [];
  markers: google.maps.LatLngLiteral[] = [];

  isEditing: boolean = false; // Flag to check if editing mode is active
  editingShelterId: string | null = null; // ID of the shelter being edited, now nullable

  mapOptions: google.maps.MapOptions = {
    zoom: 10,
    center: { lat: 37.7749, lng: -122.4194 }, // Default to San Francisco
  };

  // Location data for countries
  countries: string[] = [
    'India',
    'USA',
    'Canada',
    'UK',
    'Australia',
    'France',
    'Germany',
    'Japan',
    'China',
    'Italy',
    'Spain',
    'Brazil',
    'Russia',
    'SouthAfrica',
    'Mexico',
    'SaudiArabia',
    'Egypt',
    'UAE',
    'Turkey',
    'SouthKorea',
    'Argentina',
    'Thailand',
    'Indonesia',
    'Malaysia',
    'Sweden',
    'Norway',
  ];  
  locations: { [key: string]: string[] } = {
    India: ['Hyderabad', 'Delhi', 'Mumbai', 'Bangalore', 'Chennai', 'Kolkata', 'Pune'],
    USA: ['Atlanta', 'New York', 'San Francisco', 'Los Angeles', 'Chicago', 'Miami', 'Boston'],
    Canada: ['Toronto', 'Vancouver', 'Montreal', 'Ottawa', 'Calgary', 'Edmonton'],
    UK: ['London', 'Manchester', 'Birmingham', 'Liverpool', 'Edinburgh', 'Bristol'],
    Australia: ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Canberra'],
    France: ['Paris', 'Marseille', 'Lyon', 'Toulouse', 'Nice', 'Lille'],
    Germany: ['Berlin', 'Munich', 'Hamburg', 'Frankfurt', 'Cologne', 'Stuttgart'],
    Japan: ['Tokyo', 'Osaka', 'Kyoto', 'Hokkaido', 'Fukuoka', 'Yokohama'],
    China: ['Beijing', 'Shanghai', 'Guangzhou', 'Shenzhen', 'Chengdu', 'Hong Kong'],
    Italy: ['Rome', 'Milan', 'Florence', 'Venice', 'Naples', 'Turin'],
    Spain: ['Madrid', 'Barcelona', 'Seville', 'Valencia', 'Malaga', 'Bilbao'],
    Brazil: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador', 'Recife', 'Porto Alegre'],
    Russia: ['Moscow', 'Saint Petersburg', 'Novosibirsk', 'Yekaterinburg', 'Nizhny Novgorod', 'Kazan'],
    SouthAfrica: ['Cape Town', 'Johannesburg', 'Durban', 'Pretoria', 'Port Elizabeth'],
    Mexico: ['Mexico City', 'Guadalajara', 'Monterrey', 'Cancún', 'Tijuana', 'Puebla'],
    SaudiArabia: ['Riyadh', 'Jeddah', 'Mecca', 'Medina', 'Dammam', 'Khobar'],
    Egypt: ['Cairo', 'Alexandria', 'Giza', 'Luxor', 'Sharm El Sheikh', 'Hurghada'],
    UAE: ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Al Ain'],
    Turkey: ['Istanbul', 'Ankara', 'Izmir', 'Antalya', 'Bursa', 'Adana'],
    SouthKorea: ['Seoul', 'Busan', 'Incheon', 'Daegu', 'Gwangju', 'Daejeon'],
    Argentina: ['Buenos Aires', 'Cordoba', 'Rosario', 'Mendoza', 'La Plata'],
    Thailand: ['Bangkok', 'Chiang Mai', 'Phuket', 'Pattaya', 'Ayutthaya', 'Hua Hin'],
    Indonesia: ['Jakarta', 'Bali', 'Surabaya', 'Bandung', 'Medan'],
    Malaysia: ['Kuala Lumpur', 'Penang', 'Johor Bahru', 'Kota Kinabalu', 'Melaka'],
    Sweden: ['Stockholm', 'Gothenburg', 'Malmo', 'Uppsala', 'Vasteras'],
    Norway: ['Oslo', 'Bergen', 'Stavanger', 'Trondheim', 'Drammen'],
  };
  

  locationsToDisplay: string[] = []; // Locations to display in the dropdown
  selectedCountry: string = ''; // Selected country from dropdown
  selectedLocation: string = ''; // Selected location from dropdown

  constructor(private shelterService: ShelterService) {}

  ngOnInit(): void {
    this.fetchShelters();
  }

  fetchShelters(): void {
    this.shelterService.getShelters().subscribe((data: any) => {
      this.shelters = data;

      // Generate markers for all shelter locations
      this.markers = this.shelters.map((shelter) => {
        const [lat, lng] = this.getCoordinatesFromLocation(shelter.location);
        return { lat, lng };
      });
    });
  }

  getCoordinatesFromLocation(location: string): [number, number] {
    // const cityCoordinates: { [key: string]: [number, number] } = {
    //   Hyderabad: [17.385044, 78.486671],
    //   Delhi: [28.6139, 77.209],
    //   // Add more city coordinates as needed
    // };
    const cityCoordinates: { [key: string]: [number, number] } = {
      // India
      Hyderabad: [17.385044, 78.486671],
      Delhi: [28.6139, 77.209],
      Mumbai: [19.0760, 72.8777],
      Bangalore: [12.9716, 77.5946],
      Chennai: [13.0827, 80.2707],
      Kolkata: [22.5726, 88.3639],
      Pune: [18.5204, 73.8567],
    
      // USA
      Atlanta: [33.749, -84.388],
      New_York: [40.7128, -74.0060],
      San_Francisco: [37.7749, -122.4194],
      Los_Angeles: [34.0522, -118.2437],
      Chicago: [41.8781, -87.6298],
      Houston: [29.7604, -95.3698],
      Miami: [25.7617, -80.1918],
    
      // Canada
      Toronto: [43.65107, -79.347015],
      Vancouver: [49.2827, -123.1207],
      Montreal: [45.5017, -73.5673],
      Calgary: [51.0447, -114.0719],
    
      // UK
      London: [51.5074, -0.1278],
      Manchester: [53.4808, -2.2426],
      Birmingham: [52.4862, -1.8904],
      Edinburgh: [55.9533, -3.1883],
    
      // Australia
      Sydney: [-33.8688, 151.2093],
      Melbourne: [-37.8136, 144.9631],
      Brisbane: [-27.4698, 153.0251],
    
      // France
      Paris: [48.8566, 2.3522],
      Lyon: [45.7640, 4.8357],
      Marseille: [43.2965, 5.3698],
    
      // Germany
      Berlin: [52.5200, 13.4050],
      Munich: [48.1351, 11.5820],
      Hamburg: [53.5511, 9.9937],
    
      // Japan
      Tokyo: [35.6762, 139.6503],
      Osaka: [34.6937, 135.5023],
      Kyoto: [35.0116, 135.7681],
    
      // China
      Beijing: [39.9042, 116.4074],
      Shanghai: [31.2304, 121.4737],
      Guangzhou: [23.1291, 113.2644],
    
      // Italy
      Rome: [41.9028, 12.4964],
      Milan: [45.4642, 9.1900],
      Venice: [45.4408, 12.3155],
    
      // Spain
      Madrid: [40.4168, -3.7038],
      Barcelona: [41.3784, 2.1922],
    
      // Brazil
      Rio_de_Janeiro: [-22.9068, -43.1729],
      Sao_Paulo: [-23.5505, -46.6333],
    
      // Russia
      Moscow: [55.7558, 37.6173],
      St_Petersburg: [59.9343, 30.3351],
    
      // South Africa
      Cape_Town: [-33.9249, 18.4241],
      Johannesburg: [-26.2041, 28.0473],
    
      // Mexico
      Mexico_City: [19.4326, -99.1332],
      Guadalajara: [20.6597, -103.3496],
    
      // Saudi Arabia
      Riyadh: [24.7136, 46.6753],
      Jeddah: [21.2854, 39.2376],
    
      // Egypt
      Cairo: [30.0444, 31.2357],
    
      // UAE
      Dubai: [25.276987, 55.296249],
      Abu_Dhabi: [24.4539, 54.3773],
    
      // Turkey
      Istanbul: [41.0082, 28.9784],
    
      // South Korea
      Seoul: [37.5665, 126.9780],
    
      // Argentina
      Buenos_Aires: [-34.6037, -58.3816],
    
      // Thailand
      Bangkok: [13.7563, 100.5018],
    
      // Indonesia
      Jakarta: [-6.2088, 106.8456],
    
      // Malaysia
      Kuala_Lumpur: [3.1390, 101.6869],
    
      // Sweden
      Stockholm: [59.3293, 18.0686],
    
      // Norway
      Oslo: [59.9139, 10.7522],
    };
    

    const coords = location.split(',').map((coord) => parseFloat(coord.trim()));
    if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
      return coords as [number, number];
    }

    return cityCoordinates[location] || [0, 0];
  }

  onCountryChange(country: string): void {
    // If the selected country is valid, update the locations dropdown
    if (country && this.locations[country]) {
      this.locationsToDisplay = this.locations[country];
    } else {
      this.locationsToDisplay = [];
    }
    this.selectedLocation = ''; // Reset the selected location
  }

  createShelter(): void {
    if (this.isEditing) {
      // If in editing mode, update the shelter
      this.shelterService.updateShelter(this.editingShelterId!, this.newShelter).subscribe(() => {
        this.fetchShelters();
        this.resetForm();
      });
    } else {
      // Add a new shelter
      this.shelterService.createShelter(this.newShelter).subscribe(() => {
        this.fetchShelters();
        this.resetForm();
      });
    }
  }

  editShelter(shelter: any): void {
    this.isEditing = true;
    this.editingShelterId = shelter._id;
    this.newShelter = { ...shelter }; // Populate form with shelter details
  }

  deleteShelter(id: string): void {
    this.shelterService.deleteShelter(id).subscribe(() => {
      this.fetchShelters();
    });
  }

  cancelEdit(): void {
    this.resetForm();
  }

  private resetForm(): void {
    this.newShelter = {
      name: '',
      address: '',
      location: '',
      capacity: 0,
    };
    this.isEditing = false;
    this.editingShelterId = null;
  }
}
