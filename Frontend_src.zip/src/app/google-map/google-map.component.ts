// google-map.component.ts
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-google-map',
  templateUrl: './google-map.component.html',
  styleUrls: ['./google-map.component.css'],
})
export class GoogleMapComponent {
  @Input() markers: google.maps.LatLngLiteral[] = [];

  mapOptions: google.maps.MapOptions = {
    center: { lat: 28.6139, lng: 77.209 }, // Default to New Delhi
    zoom: 8,
  };

  markerPosition: google.maps.LatLngLiteral | null = null;
}
