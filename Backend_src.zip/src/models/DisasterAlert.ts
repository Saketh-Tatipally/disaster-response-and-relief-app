// models/DisasterAlert.ts
import mongoose, { Document, Schema } from 'mongoose';

export interface IDisasterAlert extends Document {
    type: string;
    details: string;
    location: string;
    createdAt: Date;
}

const DisasterAlertSchema: Schema = new Schema({
    type: { type: String, required: true },
    details: { type: String, required: true },
    location: {
        
            type: String,
            required: true
    },
    createdAt: { type: Date, default: Date.now },
});

// DisasterAlertSchema.index({ location: '2dsphere' }); // Create a geospatial index

const DisasterAlert = mongoose.model<IDisasterAlert>('DisasterAlert', DisasterAlertSchema);
export default DisasterAlert;
