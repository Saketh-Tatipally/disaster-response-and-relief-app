// models/Shelter.ts
import mongoose, { Document, Schema } from 'mongoose';

export interface IShelter extends Document {
    name: string;
    location: string;
    capacity: number;
    availableSpace: number;
    address: string;
}

const ShelterSchema: Schema = new Schema({
    name: { type: String, required: true },
    location: {
        type: String, required: true },
    capacity: { type: Number, required: true },
    availableSpace: { type: Number, required: false },
    address: { type: String },
});

// ShelterSchema.index({ location: '2dsphere' }); // Create a geospatial index

const Shelter = mongoose.model<IShelter>('Shelter', ShelterSchema);
export default Shelter;
