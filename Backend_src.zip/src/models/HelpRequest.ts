// models/HelpRequest.ts
import mongoose, { Document, Schema } from 'mongoose';

export interface IHelpRequest extends Document {
    userId: string;
    location: string;
    description: string;
    status: string; // e.g., "pending", "completed"
    createdAt: Date;
}

const HelpRequestSchema: Schema = new Schema({
    name: { type: String, required: true },
    location: {type: String,required:true},
    description: { type: String, required: true },
    status: { type: String, default: 'pending' },
    createdAt: { type: Date, default: Date.now },
});

// HelpRequestSchema.index({ location: '2dsphere' }); // Create a geospatial index

const HelpRequest = mongoose.model<IHelpRequest>('HelpRequest', HelpRequestSchema);
export default HelpRequest;
