// models/Donation.ts
import mongoose, { Document, Schema } from 'mongoose';

export interface IDonation extends Document {
    description: string;
    amount: number;
    title: string;
    createdAt: Date;
}

const DonationSchema: Schema = new Schema({
    description: { type: String, required: true },
    amount: { type: Number, required: true },
    title: { type: String, required: true },
    createdAt: { type: Date, default: Date.now },
});

const Donation = mongoose.model<IDonation>('Donation', DonationSchema);
export default Donation;
