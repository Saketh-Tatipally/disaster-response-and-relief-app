// routes/shelter.routes.ts
import { Router } from 'express';
import { createShelter, getShelters, updateShelter, deleteShelter } from '../controllers/shelter.controller';

const router = Router();

router.post('/', createShelter);
router.get('/', getShelters);
router.put('/:id', updateShelter);
router.delete('/:id', deleteShelter);

export default router;
