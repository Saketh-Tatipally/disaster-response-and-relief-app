// routes/alert.routes.ts
import { Router } from 'express';
import { createAlert, getAlerts, updateAlert, deleteAlert } from '../controllers/alert.controller';

const router = Router();

router.post('/', createAlert);
router.get('/', getAlerts);
router.put('/:id', updateAlert);
router.delete('/:id', deleteAlert);

export default router;
