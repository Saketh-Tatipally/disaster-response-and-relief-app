// routes/helpRequest.routes.ts
import { Router } from 'express';
import { createHelpRequest, getHelpRequests, updateHelpRequest, deleteHelpRequest } from '../controllers/helpRequest.controller';

const router = Router();

router.post('/', createHelpRequest);
router.get('/', getHelpRequests);
router.put('/:id', updateHelpRequest);
router.delete('/:id', deleteHelpRequest);

export default router;
