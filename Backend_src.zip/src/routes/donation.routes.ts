// routes/donation.routes.ts
import { Router } from 'express';
import { createDonation, getDonations, updateDonation, deleteDonation } from '../controllers/donation.controller';

const router = Router();

router.post('/', createDonation);
router.get('/', getDonations);
router.put('/:id', updateDonation);
router.delete('/:id', deleteDonation);

export default router;
