import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import alertRoutes from './routes/alert.routes';
import shelterRoutes from './routes/shelter.routes';
import helpRequestRoutes from './routes/helpRequest.routes';
import donationRoutes from './routes/donation.routes';
import connectDB from './config/db';
import cors from 'cors';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
// mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/disaster-management', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });
connectDB();

// Middleware
app.use(express.json()); // For parsing application/json
app.use(cors());

// Routes
app.use('/api/alerts', alertRoutes);
app.use('/api/shelters', shelterRoutes);
app.use('/api/help-requests', helpRequestRoutes);
app.use('/api/donations', donationRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
