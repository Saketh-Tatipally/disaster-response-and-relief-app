// controllers/alert.controller.ts
import { Request, Response } from 'express';
import DisasterAlert from '../models/DisasterAlert';

export const createAlert = async (req: Request, res: Response) => {
    try {
        const alert = new DisasterAlert(req.body);
        await alert.save();
        res.status(201).json(alert);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const getAlerts = async (req: Request, res: Response) => {
    try {
        const alerts = await DisasterAlert.find();
        res.status(200).json(alerts);
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};

export const updateAlert = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const alert = await DisasterAlert.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json(alert);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const deleteAlert = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        await DisasterAlert.findByIdAndDelete(id);
        res.status(204).send();
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};
