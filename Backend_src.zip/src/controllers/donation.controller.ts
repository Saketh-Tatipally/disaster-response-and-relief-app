// controllers/donation.controller.ts
import { Request, Response } from 'express';
import Donation from '../models/Donation';

export const createDonation = async (req: Request, res: Response) => {
    try {
        const donation = new Donation(req.body);
        await donation.save();
        res.status(201).json(donation);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const getDonations = async (req: Request, res: Response) => {
    try {
        const donations = await Donation.find();
        res.status(200).json(donations);
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};

export const updateDonation = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const donation = await Donation.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json(donation);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const deleteDonation = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        await Donation.findByIdAndDelete(id);
        res.status(204).send();
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};
