// controllers/shelter.controller.ts
import { Request, Response } from 'express';
import Shelter from '../models/Shelter';

export const createShelter = async (req: Request, res: Response) => {
    try {
        const shelter = new Shelter(req.body);
        await shelter.save();
        res.status(201).json(shelter);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const getShelters = async (req: Request, res: Response) => {
    try {
        const shelters = await Shelter.find();
        res.status(200).json(shelters);
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};

export const updateShelter = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const shelter = await Shelter.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json(shelter);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const deleteShelter = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        await Shelter.findByIdAndDelete(id);
        res.status(204).send();
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};
