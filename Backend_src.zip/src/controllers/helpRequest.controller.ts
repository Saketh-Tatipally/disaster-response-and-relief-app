// controllers/helpRequest.controller.ts
import { Request, Response } from 'express';
import HelpRequest from '../models/HelpRequest';

export const createHelpRequest = async (req: Request, res: Response) => {
    try {
        const request = new HelpRequest(req.body);
        await request.save();
        res.status(201).json(request);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const getHelpRequests = async (req: Request, res: Response) => {
    try {
        const requests = await HelpRequest.find();
        res.status(200).json(requests);
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};

export const updateHelpRequest = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const request = await HelpRequest.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json(request);
    } catch (error:any) {
        res.status(400).json({ error: error.message });
    }
};

export const deleteHelpRequest = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        await HelpRequest.findByIdAndDelete(id);
        res.status(204).send();
    } catch (error:any) {
        res.status(500).json({ error: error.message });
    }
};
